
# undead.io

Gra multiplayer w której gracz zbiera doświadczenie i pkt pokonując zombie i innych graczy, pozwala mu to na rozwój w wybranym drzewku umiejętności 


## Authors

- Aleksander Jeliński 
- Dawid Więcek
- Kinga Sokołowska
- Michał Gutowski 
- Oliwer Lendzion



## Installation

1. Create new unity project from 2D game template

2. Go to the project directory

```bash
  cd my-project
```

3. Clone the project

```bash
  git clone https://github.com/Jelinskyy/Undead.io
```

## Documentation

[Undead.io](https://gpe-my.sharepoint.com/:w:/g/personal/micguto52_edu_gdansk_pl/EShVLm4DXPVJqb_T2vWzL3kBd9en9rdF6z4v-5uu2BjiNg?fbclid=IwAR0VtJmmIJxU6Mm8HG9eptu-HaKV6LcUao748F-5EyD8HwXvsxD9j5hK0iA)

